"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const processAlerts_1 = require("./processAlerts");
// Lambda Function Handler
const handler = async (event) => {
    try {
        console.log("🔹 Lambda function started...");
        console.log("SNS Event:", JSON.stringify(event, null, 2));
        for (const record of event.Records) {
            const message = JSON.parse(record.Sns.Message);
            const { symbol, price } = message;
            if (!symbol || !price) {
                console.error("❌ Missing symbol or price in SNS message.");
                continue;
            }
            console.log(`Processing ${symbol} price: $${price}`);
            // Process the price update
            await (0, processAlerts_1.processAlerts)(symbol, price);
        }
        return {
            statusCode: 200,
            body: JSON.stringify("Alerts processed successfully"),
        };
    }
    catch (error) {
        console.error("❌ Error processing alerts:", error);
        return { statusCode: 500, body: JSON.stringify(error.message) };
    }
};
exports.handler = handler;
